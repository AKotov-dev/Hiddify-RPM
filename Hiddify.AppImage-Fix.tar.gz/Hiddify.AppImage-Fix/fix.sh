#!/bin/bash

# sudo dnf install -y curl appstream fuse

clear

HVERSION="v4.1.1"

if ! command -v curl &> /dev/null; then
    echo -e "Curl not found! Please install it before running the script!\nPress Enter to Exit..."; read a
    exit 1
fi

echo "Hiddify.AppImage-$HVERSION fix..."

echo -e "\nDownload appimagetool-x86_64.AppImage"
curl -L -O https://github.com/AppImage/appimagetool/releases/download/1.9.1/appimagetool-x86_64.AppImage
chmod +x ./appimagetool-x86_64.AppImage

echo -e "\nDownload Hiddify-Linux-x64-AppImage.tar.gz"
curl -L -O https://github.com/hiddify/hiddify-app/releases/download/$HVERSION/Hiddify-Linux-x64-AppImage.tar.gz
tar -xzvf Hiddify-Linux-x64-AppImage.tar.gz
chmod +x ./hiddify-linux-appimage/Hiddify.AppImage
echo "Extract Hiddify.AppImage"
./hiddify-linux-appimage/Hiddify.AppImage --appimage-extract

echo -e "\nFix..."
rm -fv ./squashfs-root/usr/lib/{libcrypto.so.3,libssl.so.3}
cp -fv ./hiddify.appdata.xml ./squashfs-root/usr/share/metainfo/hiddify.appdata.xml
mv -fv ./squashfs-root/hiddify.desktop ./squashfs-root/app.hiddify.com.desktop

echo -e "\nBuild ./Hiddify-x86_64.AppImage"
./appimagetool-x86_64.AppImage ./squashfs-root

echo; read -p "Press Enter to Exit..."
