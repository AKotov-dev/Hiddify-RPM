#!/bin/bash

# Инструменты
# dnf install -y appstream fuse
# sudo curl -L "https://github.com/AppImage/appimagetool/releases/download/1.9.1/appimagetool-x86_64.AppImage" -o /usr/bin/appimagetool && sudo chmod +x /usr/bin/appimagetool

rm -f ./squashfs-root/usr/lib/{libcrypto.so.3,libssl.so.3}

cp -f ./hiddify.appdata.xml ./squashfs-root/usr/share/metainfo/hiddify.appdata.xml

mv -f ./squashfs-root/hiddify.desktop app.hiddify.com.desktop

cd ./squashfs-root

appimagetool ./

# Получаем ./Hiddify-x86_64.AppImage
